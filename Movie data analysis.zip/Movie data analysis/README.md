Big Data Analytics – IMDb Dataset
=================================

Used Map-Reduce and Hadoop frameworks to derive statistics like top 10 movies, number of movies in a genre from IMDB dataset of over a million movies by running chained map-reduce jobs on a six-node cluster

##Install

This library has the java implementation IMDB movie data analysis
  
###Project Contributor

* Dinesh Appavoo ([@DineshAppavoo](https://twitter.com/DineshAppavoo))
